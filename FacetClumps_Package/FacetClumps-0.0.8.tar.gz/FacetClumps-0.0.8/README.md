# FacetClumps
FacetClumps: A molecular clump detection algorithm based on Facet model

We sincerely welcome community contributions to its optimization
